
# Declare second integer, double, and String variables.

# Read and save an integer, double, and String to your variables.
int_var = int(input())
dbl_var = float(input())
str_var = input()
# Print the sum of both integer variables on a new line.
print(i + int_var)
# Print the sum of the double variables on a new line.
print(d + dbl_var)
# Concatenate and print the String variables on a new line
# The 's' variable above should be printed first.
print(s + str_var)
