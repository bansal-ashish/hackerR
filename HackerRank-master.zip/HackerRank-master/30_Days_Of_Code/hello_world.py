input_string = input() # get a line of input from stdin and save it to our variable

# Your first line of output goes here
print('Hello, World.')

# Write the second line of output
print(input_string)
